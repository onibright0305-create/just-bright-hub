
function welcome(){
alert('Welcome to JUST BRIGHT HUB');
}
